// Online C++ compiler (editor)
// Write and run C++ online using this editor.

#include <iostream>
#include <string>
using namespace std;

int main() {
    string Customername,Phonemodelbought;
    int Quantity;
    double Priceperphone,Totalsalesamount;

    cout <<"Enter Customername:";
    getline(cin,Customername);
    cout <<"Enter Phonemodelbought:";
    getline(cin,Phonemodelbought);
    cout <<"Quantity:";
    cin>> Quantity;
    cout  <<"Priceperphone:ksh:";
    cin >>Priceperphone;

    Totalsalesamount = Quantity * Priceperphone;
    cout <<"\n==========================\n";

    cout <<"CUSTOMER RECEIPT:\n";
    
    cout << "Customername:"<<Customername<<endl;
    cout <<"Phonemodelbought:"<<Phonemodelbought<<endl;
    cout <<"Quantity:"<<Quantity<<endl;
    cout <<"priceperphone:ksh:"<<Priceperphone<<endl;
    cout <<"Totalsalesamount:"<<Totalsalesamount<<endl;

    return 0;
}
